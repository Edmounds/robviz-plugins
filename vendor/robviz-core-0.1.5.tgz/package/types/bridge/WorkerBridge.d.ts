/**
 * 主线程侧的连接代理：面板只跟它打交道，不感知 Worker 存在。
 *
 * 分发策略：
 * - raw 消息（TF 等小消息）到达即分发（TF 缓冲需要全量样本）；
 * - cloud/grid 大负载挂到 per-topic 最新槽，由渲染循环开头统一消费
 *   （flushFrame），两帧之间到达多帧只留最新，被覆盖的立即归还缓冲池。
 */
import type { ConnectionState, ServiceInfo, ServiceCallOptions, SubscribeOptions, TopicInfo } from "../core/FoxgloveConnection";
import type { MessagePayload, StreamStats } from "../worker/protocol";
export type PayloadHandler = (payload: MessagePayload, schemaName: string) => void;
export declare class WorkerBridge {
    #private;
    state: ConnectionState;
    topics: TopicInfo[];
    services: ServiceInfo[];
    stats: StreamStats | undefined;
    onStateChange?: (state: ConnectionState) => void;
    onTopicsChange?: (topics: TopicInfo[]) => void;
    onServicesChange?: (services: ServiceInfo[]) => void;
    onError?: (message: string) => void;
    onStats?: (stats: StreamStats) => void;
    /** raw 消息即时分发后调用（供渲染循环标脏） */
    onImmediateData?: () => void;
    constructor(streamingActive?: boolean);
    /**
     * 渲染循环每帧开头调用：消费大负载最新槽。
     * 返回是否有数据被分发（用于按需渲染的脏标记）。
     */
    flushFrame(): boolean;
    get url(): string | undefined;
    connect(url: string): void;
    /** 发布消息到机器人（schemaName 须在 PUB_SCHEMAS 内） */
    publish(topic: string, schemaName: string, message: unknown): void;
    /** Default 10s. null timeout waits without cancelling the remote operation. */
    callService(name: string, request: unknown, options?: ServiceCallOptions): Promise<unknown>;
    subscribe(topic: string, handler: PayloadHandler, options?: SubscribeOptions): () => void;
    /** 保持 WebSocket 在线，仅暂停非活动机器的业务订阅和帧传输。 */
    setStreamingActive(active: boolean): void;
    dispose(): void;
}
