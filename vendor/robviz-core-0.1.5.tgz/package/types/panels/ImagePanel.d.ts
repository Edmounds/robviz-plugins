import type { WorkerBridge } from "../bridge/WorkerBridge";
import type { TopicInfo } from "../core/FoxgloveConnection";
export declare function ImagePanel({ embedded, active, bridge, initialTopic, fixedTopic, mediaUrl: configuredMediaUrl, onTopicChange, onClose, }: {
    embedded?: boolean;
    active?: boolean;
    bridge: WorkerBridge;
    topics: TopicInfo[];
    /** 配置恢复：初始选中的话题 */
    initialTopic?: string;
    /** 固定预览话题；设置后不显示可切换话题选择器。 */
    fixedTopic?: string;
    /** Legacy workspace field. Preview uses the gateway's raw source name. */
    initialPreferRaw?: boolean;
    /** Legacy workspace field. Preview now always uses WebRTC. */
    initialUseWebRtc?: boolean;
    mediaUrl?: string;
    /** 配置保存：话题或传输选择变化时上报 */
    onTopicChange?: (topic: string, preferRaw: boolean, useWebRtc: boolean) => void;
    onClose: () => void;
}): import("react").JSX.Element;
