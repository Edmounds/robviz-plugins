import type { ReactNode } from "react";
export declare function CollapsiblePanel({ title, header, children, defaultCollapsed, embedded, onClose, onCollapsedChange, }: {
    title: string;
    header: ReactNode;
    children: ReactNode;
    defaultCollapsed?: boolean;
    embedded?: boolean;
    onClose: () => void;
    onCollapsedChange?: (collapsed: boolean) => void;
}): import("react").JSX.Element;
