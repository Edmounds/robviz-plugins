import { type InputHTMLAttributes, type Ref } from "react";
/** Validate every related field, not just the first invalid field. */
export declare function validateInputs(scope: ParentNode | null): boolean;
type TextProps = InputHTMLAttributes<HTMLInputElement> & {
    value: string;
    ref?: Ref<HTMLInputElement>;
};
export declare function TextInput({ onBlur, onKeyDown, onInvalid, onChange, ref, className, ...props }: TextProps): import("react").JSX.Element;
type NumberProps = Omit<TextProps, "value" | "onChange" | "type"> & {
    value: number | undefined;
    onValueChange: (value: number | undefined) => void;
    onInvalidValue?: () => void;
};
/** Keep editing text separate from the last numeric value, including empty drafts. */
export declare function NumberInput({ value, onValueChange, onInvalidValue, required, step, ...props }: NumberProps): import("react").JSX.Element;
export {};
