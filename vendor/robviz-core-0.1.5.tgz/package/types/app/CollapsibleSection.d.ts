import type { ReactNode } from "react";
export declare function CollapsibleSection({ title, children, defaultCollapsed, }: {
    title: string;
    children: ReactNode;
    defaultCollapsed?: boolean;
}): import("react").JSX.Element;
