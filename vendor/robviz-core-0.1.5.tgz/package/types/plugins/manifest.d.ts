import { z } from "zod";
export declare const SDK_API_VERSION = 1;
export declare const pluginIdSchema: z.ZodString;
export declare const packagePathSchema: z.ZodString;
export declare const pluginManifestSchema: z.ZodObject<{
    id: z.ZodString;
    name: z.ZodString;
    version: z.ZodString;
    sdkApiVersion: z.ZodLiteral<1>;
    entry: z.ZodString;
    style: z.ZodOptional<z.ZodString>;
    files: z.ZodArray<z.ZodString>;
    requiredServices: z.ZodDefault<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        protocolVersion: z.ZodNumber;
    }, z.core.$strict>>>;
}, z.core.$strict>;
export type PluginManifest = z.infer<typeof pluginManifestSchema>;
