import type { Quaternion, TimeSec, Transform, Vector3 } from "./types";
export interface Tf {
    translation: Vector3;
    rotation: Quaternion;
}
/** 查询时 time = 0 表示"取每段最新数据"（对齐 tf2 惯例） */
export declare const LATEST: TimeSec;
declare function quatMul(a: Quaternion, b: Quaternion): Quaternion;
declare function quatConj(q: Quaternion): Quaternion;
declare function quatRotate(q: Quaternion, v: Vector3): Vector3;
declare function quatSlerp(a: Quaternion, b: Quaternion, t: number): Quaternion;
/** a ∘ b：先施加 b 再施加 a（即 a_T_mid * mid_T_b） */
declare function compose(a: Tf, b: Tf): Tf;
declare function invert(t: Tf): Tf;
/**
 * tf2 语义的最小实现：每个 child frame 一条指向 parent 的边，
 * 边上是时间窗内的有序采样；查询时二分 + lerp/slerp 插值，跨 frame 走公共祖先。
 */
export declare class TfBuffer {
    #private;
    constructor(windowSec?: number);
    clear(): void;
    setTransform(parent: string, child: string, time: TimeSec, transform: Transform, isStatic?: boolean): void;
    /** 所有已知 frame（含仅作为 parent 出现的），排序稳定；结果有缓存，调用方不得修改 */
    frames(): string[];
    /** child → parent 映射，供 TF tree 面板使用 */
    tree(): Map<string, string>;
    /**
     * 求 target_T_source：把 source 系下的点变换到 target 系。
     * 链路断开或无数据时返回 undefined（调用方必须显式处理，这是 TF 调试的重要信号）。
     */
    lookup(target: string, source: string, time: TimeSec): Tf | undefined;
}
export declare const tfMath: {
    quatMul: typeof quatMul;
    quatConj: typeof quatConj;
    quatRotate: typeof quatRotate;
    quatSlerp: typeof quatSlerp;
    compose: typeof compose;
    invert: typeof invert;
};
export {};
