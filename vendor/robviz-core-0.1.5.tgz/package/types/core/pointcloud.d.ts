import type { PointCloud2 } from "./types";
export interface ParsedCloud {
    count: number;
    /** xyz 连续排布，长度 count*3 */
    positions: Float32Array;
    /** 着色标量（如 intensity），可能不存在 */
    colorValues?: Float32Array;
    colorField?: string;
    colorMin: number;
    colorMax: number;
    zMin: number;
    zMax: number;
}
/** 输出缓冲分配器：接入缓冲池时由调用方提供（返回的 buffer 可大于请求） */
export type BufferAlloc = (bytes: number) => ArrayBuffer;
/**
 * PointCloud2 → 渲染就绪的 TypedArray。设计为在 Worker 内执行，
 * 产物 Transferable 到主线程，主线程零遍历。
 *
 * 快路径：x/y/z 为连续 FLOAT32（绝大多数激光雷达驱动的布局）时按行拷贝。
 */
export declare function parsePointCloud2(msg: PointCloud2, colorField?: string, alloc?: BufferAlloc): ParsedCloud;
