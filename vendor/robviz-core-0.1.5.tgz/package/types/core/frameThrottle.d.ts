/** Return whether a frame may be delivered at the requested maximum rate. */
export declare function isFrameDue(lastDeliveredAt: number, now: number, maxFrequency?: number): boolean;
