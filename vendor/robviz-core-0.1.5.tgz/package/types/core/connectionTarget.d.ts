export declare function connectionTargetLabel(url: string): string;
export declare function validateWebSocketUrl(url: string): {
    ok: true;
    url: string;
} | {
    ok: false;
    error: string;
};
