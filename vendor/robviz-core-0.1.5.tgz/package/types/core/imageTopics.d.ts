import type { TopicInfo } from "./FoxgloveConnection";
/** Only accept sources that the video gateway has probed successfully. */
export declare function availableImageTopics(metadata: unknown): TopicInfo[];
