import type { Channel, IWebSocket } from "@foxglove/ws-protocol";
export type ConnectionState = "connecting" | "open" | "closed";
export interface TopicInfo {
    topic: string;
    schemaName: string;
}
export interface ServiceInfo {
    name: string;
    type: string;
    /** 请求 schema 文本（供 UI 生成默认请求体） */
    requestSchema: string;
    /** 响应 schema 文本（供 UI 结构化展示） */
    responseSchema: string;
}
export type MessageHandler = (message: unknown, channel: Channel) => void;
export interface SubscribeOptions {
    /** 最大交付频率；只影响本地解码/分发，不改变 WebSocket 线上字节数。 */
    maxFrequency?: number;
}
export interface ServiceCallOptions {
    /** Omit for 10s. null waits for a result or connection failure, without a timer. */
    timeoutMs?: number | null;
}
export interface MessageMeta {
    topic: string;
    /** 入站 CDR 负载字节数（无论本地是否丢弃） */
    bytes: number;
    /** 解码耗时（ms）；未解码的丢弃帧为 0 */
    decodeMs: number;
    /** 是否完成 CDR 解码并交付给至少一个 handler */
    decoded: boolean;
    /** 服务端发送时间戳（ns），用于滞后估计 */
    serverTimeNs: bigint;
}
export interface FoxgloveConnectionOptions {
    /** Node 环境注入 `ws` 包的 WebSocket；浏览器默认用原生 WebSocket */
    createWebSocket?: (url: string, protocols: string[]) => IWebSocket;
    /** 重连退避基数（ms），0 表示不重连。实际间隔按 1.7 倍指数增长至 10s，带 ±30% 抖动 */
    reconnectMs?: number;
    /**
     * 协议心跳间隔（ms），0 关闭。仅在服务端声明支持 parameters 时启用，
     * 通过只读参数请求验证连接，不依赖业务话题是否有数据。
     */
    heartbeatIntervalMs?: number;
    /** 心跳发出后收不到任何服务端响应的超时（ms）。 */
    heartbeatTimeoutMs?: number;
    onStateChange?: (state: ConnectionState) => void;
    onChannels?: (topics: TopicInfo[]) => void;
    onServices?: (services: ServiceInfo[]) => void;
    onError?: (error: Error) => void;
    /** 每条消息解码后的元信息（统计/滞后估计用） */
    onMessageMeta?: (meta: MessageMeta) => void;
}
/**
 * ws-protocol 客户端封装：按 topic 订阅、schema 驱动的 CDR 解码、断线重连。
 * 零 DOM 依赖，浏览器（Worker 内）与 Node（测试 / CLI）通用。
 */
export declare class FoxgloveConnection {
    #private;
    constructor(url: string, opts?: FoxgloveConnectionOptions);
    get topics(): TopicInfo[];
    /** 订阅 topic。channel 尚未 advertise 时挂起，advertise 后自动生效。返回退订函数。 */
    subscribe(topic: string, handler: MessageHandler, options?: SubscribeOptions): () => void;
    get services(): ServiceInfo[];
    /**
     * 客户端发布：schemaName 必须在 PUB_SCHEMAS 中（客户端编码需要 schema）。
     * 首次发布时 advertise 客户端通道，断线后自动重新 advertise。
     */
    publish(topic: string, schemaName: string, message: unknown): void;
    /** 调用服务。请求/响应 schema 来自服务端 advertise，任何类型都可调。 */
    callService(name: string, request: unknown, options?: ServiceCallOptions): Promise<unknown>;
    close(): void;
}
