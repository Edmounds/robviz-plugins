/**
 * ros2msg schema 文本（与 foxglove_bridge 广播格式一致：拼接 .msg 定义，
 * 80 个 '=' + `MSG: <pkg>/<Type>` 分隔）。客户端发布编码、
 * CLI 发布共用同一份，保证互检。
 */
export declare const TF_MESSAGE_SCHEMA: string;
export declare const LASER_SCAN_SCHEMA: string;
export declare const OCCUPANCY_GRID_SCHEMA: string;
export declare const POINT_CLOUD2_SCHEMA: string;
export declare const PATH_SCHEMA: string;
export declare const ODOMETRY_SCHEMA: string;
export declare const IMAGE_SCHEMA: string;
export declare const COMPRESSED_IMAGE_SCHEMA: string;
export declare const JOINT_STATE_SCHEMA: string;
export declare const FLOAT32_SCHEMA = "float32 data";
export declare const MARKER_ARRAY_SCHEMA: string;
export declare const TWIST_SCHEMA: string;
export declare const POSE_STAMPED_SCHEMA: string;
export declare const POSE_WITH_COVARIANCE_STAMPED_SCHEMA: string;
export declare const STRING_SCHEMA = "string data";
export declare const BOOL_SCHEMA = "bool data";
/** 客户端可发布的类型库：schemaName → schema 文本 */
export declare const PUB_SCHEMAS: Record<string, string>;
export declare const SET_BOOL_REQUEST_SCHEMA = "bool data";
export declare const SET_BOOL_RESPONSE_SCHEMA = "bool success\nstring message";
/** ROS2 空消息在 CDR 里有一个占位字节 */
export declare const TRIGGER_REQUEST_SCHEMA = "uint8 structure_needs_at_least_one_member";
export declare const TRIGGER_RESPONSE_SCHEMA = "bool success\nstring message";
