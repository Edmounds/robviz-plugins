/**
 * 3D 场景主题色:UI chrome 用 CSS 令牌,three.js 材质无法读 CSS 变量,
 * 由本模块提供当前主题的场景配色 + 变更订阅(Grid/Path 等骨架线条用;
 * TF 轴 RGB、点云 colormap 属数据色,不跟随主题)。
 */
export type Theme = "dark" | "light";
export interface SceneColors {
    /** 视口背景 */
    background: number;
    /** 骨架线条(网格、路径) */
    foreground: number;
    /** 无强度点云的回退色(纯白/纯黑点在对应背景上不可见) */
    flatPoint: number;
}
export declare function getSceneTheme(): Theme;
export declare function sceneColors(theme?: Theme): SceneColors;
export declare function setSceneTheme(theme: Theme): void;
/** 订阅主题变更,返回取消函数 */
export declare function onSceneTheme(fn: (theme: Theme) => void): () => void;
