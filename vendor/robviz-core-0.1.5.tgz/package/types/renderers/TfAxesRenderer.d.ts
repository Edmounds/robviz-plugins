import * as THREE from "three";
import { TfBuffer } from "../core/TfBuffer";
import type { TimeSec } from "../core/types";
export declare function computeTfLabelHeight(fontScale: number, viewportHeight: number, fovDeg: number): number;
/** 每个已知 TF frame 一组坐标轴 + 名称标签，由 SceneManager 每帧驱动 */
export declare class TfAxesRenderer {
    #private;
    readonly root: THREE.Group<THREE.Object3DEventMap>;
    constructor();
    dispose(): void;
    setLineWidth(lineWidth: number): void;
    updateProjection(effectiveFontScale: number, viewportHeight: number, fovDeg: number): void;
    tick(tf: TfBuffer, fixedFrame: string, broken: Set<string>, time: TimeSec): void;
}
