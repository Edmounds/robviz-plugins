import * as THREE from "three";
import { TfBuffer } from "../core/TfBuffer";
import type { TimeSec } from "../core/types";
import type { MessagePayload } from "../worker/protocol";
/** 一种消息类型的 3D 显示器 */
export interface Display {
    readonly root: THREE.Object3D;
    /** 最近一条消息的 frame_id，SceneManager 每帧按它求 TF */
    frameId: string | undefined;
    update(payload: MessagePayload): void;
    dispose(): void;
    /**
     * 自定义 TF 放置（内部含多个 frame 的显示器，如 MarkerArray、URDF）。
     * 定义了则 SceneManager 跳过标准的 frameId 整体变换，逐帧调用本方法。
     */
    tick?(tf: TfBuffer, fixedFrame: string, time: TimeSec, broken: Set<string>): void;
}
export interface SceneStats {
    /** 实际渲染帧率（按需渲染：空闲时趋近 0，这是特性不是问题） */
    renderHz: number;
    brokenFrames: string[];
    /** 当前 TF 平滑延迟（ms），随网络抖动自适应 */
    tfDelayMs: number;
}
export declare function stopHandledPointerDown(event: Pick<PointerEvent, "defaultPrevented" | "stopImmediatePropagation">): void;
export declare function preventGestureDefault(event: Event): void;
export declare function computeTfBounds(tf: TfBuffer, fixedFrame: string, time: TimeSec, axisLen?: number): THREE.Box3 | null;
export declare function computeFitCameraDistance(box: THREE.Box3, fovDeg: number, aspect: number, margin?: number, center?: THREE.Vector3): {
    center: THREE.Vector3;
    dist: number;
};
export declare class SceneManager {
    #private;
    onStats?: (stats: SceneStats) => void;
    /** 每帧渲染前调用（挂 WorkerBridge.flushFrame），返回 true 表示有新数据 */
    onBeforeRender?: () => boolean;
    constructor(canvas: HTMLCanvasElement, tf: TfBuffer);
    get fixedFrame(): string;
    /** 供框选等工具计算投影 */
    get camera(): THREE.PerspectiveCamera;
    /** 框选工具激活时关闭轨道控制 */
    setControlsEnabled(enabled: boolean): void;
    enableAutoFitTf(): void;
    setFontScale(scale: number): void;
    setGridVisible(visible: boolean): void;
    setTfAxesLineWidth(lineWidth: number): void;
    setLightingVisible(visible: boolean): void;
    setShadowsEnabled(enabled: boolean): void;
    set fixedFrame(frame: string);
    get followFrame(): string | undefined;
    /**
     * 视角跟踪：每帧把观察中心锁到该 frame 原点（rviz Target Frame 式）。
     * 跟踪中轨道旋转/缩放仍然自由，只锁定中心；undefined 取消。
     */
    setFollowFrame(frame: string | undefined): void;
    /** 外部数据更新后标脏（按需渲染） */
    invalidate(): void;
    setActive(active: boolean): void;
    /**
     * 相机平滑飞行。显式调用取消待执行的 TF 自动适配。
     */
    flyTo(target: THREE.Vector3, position?: THREE.Vector3, durationMs?: number): void;
    /** 飞回默认机位（显式调用取消待执行的 TF 自动适配） */
    resetView(): void;
    /** 重新适配当前 TF 视野，无有效 TF 时回默认机位 */
    resetViewToTf(): void;
    /** 当前相机位姿（配置文件保存用） */
    getCameraState(): {
        position: [number, number, number];
        target: [number, number, number];
    };
    /** 恢复相机位姿（配置文件加载用，瞬时不做动画） */
    setCameraState(state: {
        position: [number, number, number];
        target: [number, number, number];
    }): void;
    /** 飞到能看全包围盒的视距（保持当前观察方向），显式调用取消待执行的 TF 自动适配 */
    flyToFit(box: THREE.Box3, durationMs?: number): void;
    /** App 在每条 TF 消息后调用：驱动平滑延迟自适应 */
    reportTf(newestStampSec: TimeSec): void;
    addDisplay(topic: string, display: Display): void;
    removeDisplay(topic: string): void;
    getDisplay(topic: string): Display | undefined;
    dispose(): void;
    /** 显示器被禁用时上报（App 层提示用户） */
    onDisplayError?: (topic: string, message: string) => void;
}
