/**
 * WebRTC Video Stream Client & Multi-Panel Manager for RobViz
 * Handles on-demand WebRTC peer connections, dynamic bitrate telemetry,
 * and shared media streams for identical ROS image topics across multiple panels.
 */
import type { TopicInfo } from "../core/FoxgloveConnection";
export interface WebRtcStreamStats {
    topic: string;
    targetFps: number;
    actualFps: number;
    bitrateKbps: number;
    width: number;
    height: number;
    packetLoss: number;
    encoderBitrateKbps?: number;
    /** 网关明确报告的源编码；不能从 Image schema 或话题名猜测颜色/深度。 */
    sourceEncoding?: string;
    rtt: number;
    encoder: string;
    status: "idle" | "connecting" | "streaming" | "congested" | "error" | "stopped";
    statusText?: string;
    transport?: "webrtc" | "jpeg";
    compressedTopic?: string;
}
export type WebRtcStatsCallback = (stats: WebRtcStreamStats) => void;
export type WebRtcStreamCallback = (stream: MediaStream | null) => void;
/**
 * Singleton manager to share WebRTC stream connections across multiple panels for the same topic.
 */
declare class WebRtcStreamManager {
    private peers;
    /** Discover sources without opening video peers or subscribing via Foxglove. */
    discover(wsUrl: string, onTopics: (topics: TopicInfo[]) => void): () => void;
    /**
     * Helper to derive the gateway WebSocket URL from Foxglove bridge URL
     */
    deriveMediaUrl(foxgloveUrl: string, explicitMediaUrl?: string): string;
    watch(topic: string, wsUrl: string, viewerId: string, targetFps: number, onStream: WebRtcStreamCallback, onStats: WebRtcStatsCallback): () => void;
    setFps(topic: string, wsUrl: string, viewerId: string, fps: number): void;
    reconnect(topic: string, wsUrl: string): void;
}
export declare const webRtcManager: WebRtcStreamManager;
export {};
