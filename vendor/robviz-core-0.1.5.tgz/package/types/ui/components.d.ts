import { type ButtonHTMLAttributes, type ComponentProps, type HTMLAttributes, type InputHTMLAttributes, type ReactNode, type SelectHTMLAttributes, type TextareaHTMLAttributes } from "react";
import { Group, Panel, Separator } from "react-resizable-panels";
export { TextInput, NumberInput } from "../app/EditableInput";
export { Group as SplitGroup, Panel as SplitPanel };
export declare function Button({ variant, selected, className, type, ...props }: ButtonHTMLAttributes<HTMLButtonElement> & {
    variant?: "default" | "primary" | "danger";
    selected?: boolean;
}): import("react").JSX.Element;
export declare function IconButton({ label, className, ...props }: ComponentProps<typeof Button> & {
    label: string;
}): import("react").JSX.Element;
export declare function Select({ className, ...props }: SelectHTMLAttributes<HTMLSelectElement>): import("react").JSX.Element;
export declare function TextArea({ className, ...props }: TextareaHTMLAttributes<HTMLTextAreaElement>): import("react").JSX.Element;
export declare function Checkbox({ children, className, ...props }: Omit<InputHTMLAttributes<HTMLInputElement>, "type"> & {
    children: ReactNode;
}): import("react").JSX.Element;
/** One labelled control. Preserve native label association for inputs and selects. */
export declare function Field({ label, hint, children, className, ...props }: HTMLAttributes<HTMLLabelElement> & {
    label: ReactNode;
    hint?: ReactNode;
}): import("react").JSX.Element;
export declare function Page({ className, ...props }: ComponentProps<"div">): import("react").JSX.Element;
/** Content only: Dockview continues to own docked panel titles and actions. */
export declare function PanelBody({ className, ...props }: ComponentProps<"div">): import("react").JSX.Element;
export declare function Toolbar({ className, ...props }: HTMLAttributes<HTMLDivElement>): import("react").JSX.Element;
export declare function ActionRow({ className, ...props }: ComponentProps<"div">): import("react").JSX.Element;
/** For sections inside standalone pages, not another frame inside Dockview. */
export declare function Section({ title, actions, children, className, ...props }: Omit<HTMLAttributes<HTMLElement>, "title"> & {
    title: ReactNode;
    actions?: ReactNode;
}): import("react").JSX.Element;
export type StatusTone = "neutral" | "warning" | "error";
export declare function StatusBadge({ tone, className, ...props }: HTMLAttributes<HTMLSpanElement> & {
    tone?: StatusTone;
}): import("react").JSX.Element;
export declare function Notice({ tone, className, ...props }: HTMLAttributes<HTMLDivElement> & {
    tone?: StatusTone;
}): import("react").JSX.Element;
export declare function EmptyState({ className, ...props }: HTMLAttributes<HTMLParagraphElement>): import("react").JSX.Element;
export declare function SplitHandle({ className, ...props }: ComponentProps<typeof Separator>): import("react").JSX.Element;
