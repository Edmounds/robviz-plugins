import { type Ref } from "react";
import { Terminal } from "@xterm/xterm";
import "@xterm/xterm/css/xterm.css";
export type LogTerminalHandle = Pick<Terminal, "write" | "reset" | "clear">;
/** Read-only ANSI log display. Network requests and cursors belong to callers. */
export default function LogTerminal({ ref, theme, active, fontScale, label, initialText }: {
    ref?: Ref<LogTerminalHandle>;
    theme: "dark" | "light";
    active?: boolean;
    fontScale?: number;
    label: string;
    initialText?: string;
}): import("react").JSX.Element;
